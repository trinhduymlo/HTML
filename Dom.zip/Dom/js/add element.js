
var newEl = document.createElement('li');


var newtext = document.createTextNode('quinoa');


newEl.appendChild(newtext);


var position = document.getElementsByTagName('ul')[0];


position.appendChild(newEl;
)

