
var starItem = document.getElementsByTagName('ul');
var firstItem = starItem.firstChild;
var lastItem = starItem.lastChild;


firstItem.className = 'complete';
lastItem.className = 'cool';
