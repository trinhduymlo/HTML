
var removeEl = document.getElementsByClassName('li')[3];


var containerEl = document.getElementsByClassName('ul')[0];


containerEl.removeChild(removeEl);

