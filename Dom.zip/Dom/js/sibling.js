
var starItem = document.getElementById('two');
var prevItem = starItem.previousElementSibling;
var nextItem = starItem.nextSibling;


prevItem.className = 'complete';
nextItem.className = 'cool';

