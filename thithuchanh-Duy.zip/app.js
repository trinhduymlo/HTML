// Code goes here

var app = angular.module("myApp", []);

app.controller("myCtrl", function($scope){
	console.log("My controller.....");
		
		
		$scope.users = [
			{name: "Nguyễn Văn Tấn", email: "tannv1@vnpt.vn", fullname: "abc abc"},
			{name: "Cao Kim hạnh", email: "Caohanh@vnpt.vn", fullname: "Cô giáo Kim Thi"},
			{name: "Đi học 2-9", email: "CoThi@fpt.com", fullname: "ghi ghi"}
		];

	$scope.addUser = function(){
		$scope.users.push($scope.newUser);
		$scope.newUser = {};
		$scope.message = "New User Added successfully";
	};
	
	$scope.selectUser = function(user){
		console.log(user);
		$scope.clickedUser = user;
	};

	$scope.editUser = function(){
		$scope.message = "User Edited successfully";
	};

	$scope.deleteUser = function(){
		$scope.users.splice($scope.users.indexOf($scope.clickedUser));
		$scope.message = "User Deleted successfully";
	};

	$scope.clearMessage = function(){
		$scope.message = "";
	};

});